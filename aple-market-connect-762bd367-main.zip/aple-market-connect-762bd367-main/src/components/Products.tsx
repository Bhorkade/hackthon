import { useState, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import onionImg from '@/assets/onion.jpg';
import potatoImg from '@/assets/potato.jpg';
import tomatoImg from '@/assets/tomato.jpg';
import chiliPowderImg from '@/assets/chili-powder.jpg';
import turmericImg from '@/assets/turmeric.jpg';
import oilImg from '@/assets/oil.jpg';

const Products = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const { toast } = useToast();

  const products = [
    { id: 1, name: 'कांदा', category: 'vegetable', price: 25, unit: 'किलो', image: onionImg },
    { id: 2, name: 'बटाटा', category: 'vegetable', price: 30, unit: 'किलो', image: potatoImg },
    { id: 3, name: 'टोमॅटो', category: 'vegetable', price: 40, unit: 'किलो', image: tomatoImg },
    { id: 4, name: 'लाल तिखट', category: 'spice', price: 80, unit: '२५० ग्रॅम', image: chiliPowderImg },
    { id: 5, name: 'हळद', category: 'spice', price: 60, unit: '२५० ग्रॅम', image: turmericImg },
    { id: 6, name: 'शेंगदाणा तेल', category: 'oil', price: 180, unit: 'लिटर', image: oilImg },
  ];

  const filteredProducts = useMemo(() => {
    return products.filter(product => {
      const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesCategory = selectedCategory === 'all' || product.category === selectedCategory;
      return matchesSearch && matchesCategory;
    });
  }, [searchTerm, selectedCategory]);

  const handleOrder = (productName: string) => {
    toast({
      title: "ऑर्डर प्राप्त झाला!",
      description: `${productName} साठी तुमचा ऑर्डर प्राप्त झाला आहे.`,
    });
  };

  return (
    <section id="products" className="py-20 bg-secondary/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
            उत्पादने आणि दर
          </h2>
          <div className="w-24 h-1 gradient-primary mx-auto rounded-full"></div>
        </div>

        {/* Filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-12 max-w-2xl mx-auto">
          <Input
            type="text"
            placeholder="उत्पादन शोधा (उदा. कांदा, बटाटा)"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="flex-1 h-12 text-base shadow-card"
          />
          <Select value={selectedCategory} onValueChange={setSelectedCategory}>
            <SelectTrigger className="w-full md:w-48 h-12 shadow-card">
              <SelectValue placeholder="सर्व प्रकार" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">सर्व प्रकार</SelectItem>
              <SelectItem value="vegetable">भाजीपाला</SelectItem>
              <SelectItem value="spice">मसाले</SelectItem>
              <SelectItem value="oil">तेल</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProducts.map((product) => (
            <div
              key={product.id}
              className="gradient-card rounded-2xl overflow-hidden shadow-card hover:shadow-hover transition-smooth transform hover:-translate-y-2 group"
            >
              <div className="relative overflow-hidden">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-48 object-cover transition-smooth group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-primary/30 to-transparent opacity-0 group-hover:opacity-100 transition-smooth"></div>
              </div>
              
              <div className="p-6">
                <h3 className="text-2xl font-semibold text-foreground mb-2 group-hover:text-primary transition-smooth">
                  {product.name}
                </h3>
                <div className="mb-4">
                  <span className="text-3xl font-bold text-primary">₹{product.price}</span>
                  <span className="text-muted-foreground ml-2">प्रति {product.unit}</span>
                </div>
                <Button 
                  variant="card" 
                  size="lg" 
                  className="w-full"
                  onClick={() => handleOrder(product.name)}
                >
                  ऑर्डर करा
                </Button>
              </div>
            </div>
          ))}
        </div>

        {filteredProducts.length === 0 && (
          <div className="text-center py-12">
            <p className="text-xl text-muted-foreground">
              कोणतेही उत्पादन सापडले नाही. कृपया आपला शोध बदला.
            </p>
          </div>
        )}
      </div>
    </section>
  );
};

export default Products;