import { Button } from '@/components/ui/button';
import heroBg from '@/assets/hero-bg.jpg';

const Hero = () => {
  const scrollToProducts = () => {
    document.getElementById('products')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section 
      className="relative min-h-[70vh] flex items-center justify-center text-white overflow-hidden"
      style={{
        backgroundImage: `linear-gradient(rgba(0,0,0,0.6), rgba(255,111,0,0.3)), url(${heroBg})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat'
      }}
    >
      {/* Background overlay with gradient */}
      <div className="absolute inset-0 gradient-hero opacity-80"></div>
      
      {/* Content */}
      <div className="relative z-10 text-center max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
          तुमच्या व्यवसायासाठी ताजा आणि स्वस्त कच्चा माल
        </h1>
        <p className="text-xl md:text-2xl mb-8 text-white/90 font-medium">
          थेट घाऊक विक्रेत्यांकडून, तुमच्या दारात.
        </p>
        <Button 
          variant="hero" 
          size="xl" 
          onClick={scrollToProducts}
          className="text-lg px-12 py-4"
        >
          आजचे दर पहा
        </Button>
      </div>
      
      {/* Decorative elements */}
      <div className="absolute top-10 left-10 w-20 h-20 bg-white/10 rounded-full blur-xl"></div>
      <div className="absolute bottom-20 right-10 w-32 h-32 bg-primary/20 rounded-full blur-2xl"></div>
      <div className="absolute top-1/3 right-20 w-16 h-16 bg-accent/30 rounded-full blur-lg"></div>
    </section>
  );
};

export default Hero;