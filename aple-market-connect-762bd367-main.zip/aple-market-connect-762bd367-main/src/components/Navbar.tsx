import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Menu, X } from 'lucide-react';

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);

  return (
    <nav className="bg-card shadow-card sticky top-0 z-50 backdrop-blur-sm border-b border-border/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex-shrink-0">
            <h1 className="text-2xl font-bold gradient-primary bg-clip-text text-transparent">
              आपले मार्केट
            </h1>
          </div>

          {/* Desktop Menu */}
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-8">
              <a 
                href="#features" 
                className="text-foreground hover:text-primary transition-smooth font-medium"
              >
                वैशिष्ट्ये
              </a>
              <a 
                href="#products" 
                className="text-foreground hover:text-primary transition-smooth font-medium"
              >
                उत्पादने
              </a>
              <Button variant="hero" size="default">
                लॉगिन
              </Button>
            </div>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <Button variant="ghost" size="icon" onClick={toggleMenu}>
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden absolute top-16 left-0 right-0 bg-card shadow-card border-b border-border/50 backdrop-blur-sm">
            <div className="px-2 pt-2 pb-3 space-y-1">
              <a
                href="#features"
                className="block px-3 py-2 text-foreground hover:text-primary transition-smooth font-medium"
                onClick={toggleMenu}
              >
                वैशिष्ट्ये
              </a>
              <a
                href="#products"
                className="block px-3 py-2 text-foreground hover:text-primary transition-smooth font-medium"
                onClick={toggleMenu}
              >
                उत्पादने
              </a>
              <div className="px-3 py-2">
                <Button variant="hero" size="default" className="w-full">
                  लॉगिन
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;