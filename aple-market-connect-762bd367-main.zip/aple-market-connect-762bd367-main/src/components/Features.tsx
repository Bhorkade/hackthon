import groupBuyingImg from '@/assets/group-buying.jpg';
import fastDeliveryImg from '@/assets/fast-delivery.jpg';
import qualityImg from '@/assets/quality.jpg';

const Features = () => {
  const features = [
    {
      id: 1,
      title: 'सामूहिक खरेदी',
      description: 'एकत्र ऑर्डर करा आणि मोठी बचत मिळवा.',
      image: groupBuyingImg,
    },
    {
      id: 2,
      title: 'जलद डिलिव्हरी',
      description: 'ऑर्डर केलेला माल वेळेवर तुमच्यापर्यंत पोहोचे.',
      image: fastDeliveryImg,
    },
    {
      id: 3,
      title: 'उत्तम गुणवत्ता',
      description: 'तपासणी केलेला आणि ताज्या मालाची हमी.',
      image: qualityImg,
    },
  ];

  return (
    <section id="features" className="py-20 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
            आमची वैशिष्ट्ये
          </h2>
          <div className="w-24 h-1 gradient-primary mx-auto rounded-full"></div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature) => (
            <div
              key={feature.id}
              className="gradient-card rounded-2xl p-8 text-center shadow-card hover:shadow-hover transition-smooth transform hover:-translate-y-2 group"
            >
              <div className="mb-6 relative overflow-hidden rounded-xl">
                <img
                  src={feature.image}
                  alt={feature.title}
                  className="w-full h-48 object-cover transition-smooth group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-primary/20 to-transparent opacity-0 group-hover:opacity-100 transition-smooth"></div>
              </div>
              <h3 className="text-2xl font-semibold text-foreground mb-4 group-hover:text-primary transition-smooth">
                {feature.title}
              </h3>
              <p className="text-muted-foreground text-lg leading-relaxed">
                {feature.description}
              </p>
              <div className="mt-6 w-16 h-1 bg-primary/20 group-hover:bg-primary mx-auto rounded-full transition-smooth"></div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;