const Footer = () => {
  return (
    <footer className="bg-foreground text-background py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <div className="mb-4">
            <h3 className="text-2xl font-bold gradient-primary bg-clip-text text-transparent">
              आपले मार्केट
            </h3>
          </div>
          <p className="text-background/80">
            &copy; २०२५ आपले मार्केट. सर्व हक्क राखीव.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;